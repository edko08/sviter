create function show_users()
  returns refcursor
language plpgsql
as $$
DECLARE
      ref refcursor;
    BEGIN
      OPEN ref FOR SELECT * FROM users;
      RETURN ref;
    END;
$$;

alter function show_users()
  owner to edko;

